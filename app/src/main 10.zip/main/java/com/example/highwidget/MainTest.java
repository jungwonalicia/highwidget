package com.example.highwidget;

public class MainTest {
    public static void main(String[] args) {
        System.out.println("welcome");
    }
}
